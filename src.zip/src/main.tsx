import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
//styles
import "@scss/main.scss";

const root = document.getElementById("root");

if (!root) {
  throw new Error("Root element was not found");
}

createRoot(root).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
