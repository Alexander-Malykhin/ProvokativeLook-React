import Modal from "@UI/overlays/Modal/Modal";
import styles from "./AuthModal.module.scss";
import AuthTabs from "./components/AuthTabs";
import ConfirmEmailForm from "./components/ConfirmEmailForm";
import LoginForm from "./components/LoginForm";
import RegisterForm from "./components/RegisterForm";
import ResetPasswordRequestForm from "./components/ResetPasswordRequestForm";
import ResetPasswordConfirmForm from "./components/ResetPasswordConfirmForm";
import { useAuthFlow } from "./hooks/useAuthFlow";

const AuthModal = () => {
  const auth = useAuthFlow();

  return (
    <Modal
      open={auth.active}
      onClose={auth.close}
      overlayClassName={styles.overlay}
      contentClassName={styles.modal}
      ariaLabelledBy="auth-modal-title"
      closeDisabled={false}
    >
      <button
        type="button"
        className={styles.modal__close}
        onClick={auth.close}
        aria-label="Закрыть"
      >
        <span />
        <span />
      </button>

      {(auth.mode === "login" || auth.mode === "register") && (
        <AuthTabs
          mode={auth.mode}
          disabled={auth.isLoginLoading || auth.isRegisterLoading}
          onChange={auth.changeMode}
        />
      )}

      {auth.mode === "login" && (
        <LoginForm
          form={auth.loginForm}
          isLoading={auth.isLoginLoading}
          errorMessage={auth.errorMessage}
          successMessage={auth.successMessage}
          fieldErrors={auth.loginFieldErrors}
          onChange={auth.handleLoginChange}
          onSubmit={(event) => void auth.submitLogin(event)}
          onSwitch={() => auth.changeMode("register")}
          onForgotPassword={() => auth.changeMode("resetRequest")}
        />
      )}

      {auth.mode === "register" && (
        <RegisterForm
          form={auth.registerForm}
          isLoading={auth.isRegisterLoading}
          errorMessage={auth.errorMessage}
          fieldErrors={auth.registerFieldErrors}
          onChange={auth.handleRegisterChange}
          onSubmit={(event) => void auth.submitRegister(event)}
          onSwitch={() => auth.changeMode("login")}
        />
      )}

      {auth.mode === "resetRequest" && (
        <ResetPasswordRequestForm
          email={auth.resetForm.email}
          isLoading={auth.isResetLoading}
          errorMessage={auth.errorMessage}
          successMessage={auth.successMessage}
          onEmailChange={auth.handleResetEmailChange}
          onSubmit={(event) => void auth.submitResetRequest(event)}
          onBack={() => auth.changeMode("login")}
        />
      )}

      {auth.mode === "resetConfirm" && (
        <ResetPasswordConfirmForm
          email={auth.resetForm.email}
          code={auth.resetForm.code}
          password={auth.resetForm.password}
          confirmPassword={auth.resetForm.confirmPassword}
          isLoading={auth.isResetLoading}
          errorMessage={auth.errorMessage}
          successMessage={auth.successMessage}
          onChange={auth.handleResetChange}
          onSubmit={(event) => void auth.submitResetConfirm(event)}
          onBack={() => auth.changeMode("login")}
        />
      )}

      {auth.mode === "confirm" && (
        <ConfirmEmailForm
          email={auth.registerForm.email}
          code={auth.confirmForm.code}
          isLoading={auth.isConfirmLoading}
          errorMessage={auth.errorMessage}
          successMessage={auth.successMessage}
          onCodeChange={auth.handleConfirmChange}
          onSubmit={(event) => void auth.submitConfirm(event)}
          onBack={() => auth.changeMode("register")}
        />
      )}
    </Modal>
  );
};

export default AuthModal;
